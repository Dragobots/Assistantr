package com.studyassistant.mobile

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AssistantApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssistantApp() {
    val context = LocalContext.current
    var command by remember { mutableStateOf("") }
    var plan by remember { mutableStateOf<AssistantPlan?>(null) }
    var running by remember { mutableStateOf(false) }
    var stopped by remember { mutableStateOf(false) }
    var awaitingConfirmation by remember { mutableStateOf(false) }
    var activityLog by remember { mutableStateOf(listOf("Ready for your order")) }
    var screenReaderEnabled by remember { mutableStateOf(isScreenReaderEnabled(context)) }
    var screenContextEnabled by remember { mutableStateOf(ScreenContextStore.acceptingContext) }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("Study Assistant", fontWeight = FontWeight.Bold)
                            Text("Command console", style = MaterialTheme.typography.labelSmall)
                        }
                    },
                    actions = {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Voice command available",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(end = 16.dp),
                        )
                    },
                )
            },
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFFF7F7FB))
                    .padding(padding)
                    .padding(horizontal = 18.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Spacer(Modifier.height(4.dp))
                Text(
                    "Give one order. I’ll plan it, read the active screen when enabled, and keep you informed.",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.SemiBold,
                )

                ScreenReaderCard(
                    enabled = screenReaderEnabled,
                    contextUseEnabled = screenContextEnabled,
                    onEnable = {
                        context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    },
                    onRefresh = {
                        screenReaderEnabled = isScreenReaderEnabled(context)
                        screenContextEnabled = ScreenContextStore.acceptingContext
                    },
                    onStop = {
                        ScreenContextStore.stopContextUse()
                        screenContextEnabled = false
                        activityLog = activityLog + "Screen context stopped"
                    },
                    onDisable = {
                        context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    },
                )

                OutlinedTextField(
                    value = command,
                    onValueChange = { command = it },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3,
                    label = { Text("What should I do?") },
                    placeholder = { Text("Open WhatsApp and send hi to Abay") },
                    shape = RoundedCornerShape(18.dp),
                )

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = {
                            val screenContext = ScreenContextStore.latest.takeIf { screenContextEnabled && ScreenContextStore.acceptingContext }
                            plan = CommandPlanner.plan(command, screenContext)
                            running = false
                            stopped = false
                            awaitingConfirmation = false
                            activityLog = listOf("Planned: ${command.trim()}")
                        },
                        enabled = command.isNotBlank(),
                    ) {
                        Text("Plan order")
                    }
                    OutlinedButton(
                        onClick = {
                            command = ""
                            plan = null
                            running = false
                            stopped = true
                            awaitingConfirmation = false
                            activityLog = activityLog + "Stopped by user"
                        },
                    ) {
                        Icon(Icons.Default.Stop, contentDescription = "Stop")
                        Spacer(Modifier.size(6.dp))
                        Text("Stop")
                    }
                }

                plan?.let { currentPlan ->
                    PlanCard(
                        plan = currentPlan,
                        running = running,
                        stopped = stopped,
                        awaitingConfirmation = awaitingConfirmation,
                        onRun = {
                            running = true
                            stopped = false
                            val executionContext = ScreenContextStore.latest.takeIf { screenContextEnabled && ScreenContextStore.acceptingContext }
                            val decision = ActionExecutor.decide(command, executionContext)
                            activityLog = activityLog + "Started plan" + decision.explanation
                            awaitingConfirmation = currentPlan.requiresConfirmation
                            if (decision.shouldOpenWhatsApp) {
                                val intent = context.packageManager.getLaunchIntentForPackage("com.whatsapp")
                                if (intent != null) {
                                    context.startActivity(intent)
                                    activityLog = activityLog + "Opened WhatsApp"
                                } else {
                                    Toast.makeText(context, "WhatsApp is not installed", Toast.LENGTH_LONG).show()
                                }
                            }
                        },
                        onConfirm = {
                            awaitingConfirmation = false
                            running = false
                            activityLog = activityLog + "Approved for manual send; no message was sent automatically"
                        },
                        onCancel = {
                            awaitingConfirmation = false
                            running = false
                            stopped = true
                            activityLog = activityLog + "Sensitive action cancelled"
                        },
                    )
                }

                ActivityHistory(activityLog)
            }
        }
    }
}

@Composable
private fun ScreenReaderCard(
    enabled: Boolean,
    contextUseEnabled: Boolean,
    onEnable: () -> Unit,
    onRefresh: () -> Unit,
    onStop: () -> Unit,
    onDisable: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = if (enabled) Color(0xFFEAF7F0) else Color.White),
        shape = RoundedCornerShape(20.dp),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Security, contentDescription = null, tint = if (enabled) Color(0xFF16794D) else MaterialTheme.colorScheme.primary)
                Spacer(Modifier.size(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Screen reading", fontWeight = FontWeight.SemiBold)
                    Text(
                        when {
                            !enabled -> "Enable Android access to read the active app"
                            contextUseEnabled -> "Reading accessible screen text"
                            else -> "Service enabled; screen context is stopped"
                        },
                    )
                }
                if (contextUseEnabled) Icon(Icons.Default.CheckCircle, contentDescription = "Screen reading active", tint = Color(0xFF16794D))
            }
            if (enabled && !contextUseEnabled) {
                Text("Screen context is stopped in the app. To disable Android access entirely, use Settings.", style = MaterialTheme.typography.bodySmall)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!enabled) Button(onClick = onEnable) { Text("Enable") }
                if (contextUseEnabled) OutlinedButton(onClick = onStop) { Text("Stop reading") }
                if (enabled && !contextUseEnabled) OutlinedButton(onClick = onDisable) { Text("Disable in Settings") }
                OutlinedButton(onClick = onRefresh) { Text("Refresh") }
            }
        }
    }
}

@Composable
private fun PlanCard(
    plan: AssistantPlan,
    running: Boolean,
    stopped: Boolean,
    awaitingConfirmation: Boolean,
    onRun: () -> Unit,
    onConfirm: () -> Unit,
    onCancel: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(20.dp),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Plan", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(plan.request, color = MaterialTheme.colorScheme.onSurfaceVariant)
            LinearProgressIndicator(progress = if (running) 0.35f else 0f, modifier = Modifier.fillMaxWidth())
            plan.steps.forEachIndexed { index, step ->
                Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("${index + 1}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Column {
                        Text(step.title, fontWeight = FontWeight.SemiBold)
                        Text(step.detail, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            if (plan.requiresConfirmation) {
                Text("Sensitive actions pause for your confirmation before they are sent or submitted.", color = MaterialTheme.colorScheme.primary)
            }
            if (stopped) Text("Stopped. No further actions will run.", color = MaterialTheme.colorScheme.error)
            if (awaitingConfirmation) {
                Text("WhatsApp is open. Confirm the recipient and message before continuing.", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onConfirm, modifier = Modifier.weight(1f)) { Text("Confirm") }
                    OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("Cancel") }
                }
            } else {
                Button(onClick = onRun, enabled = !running && !stopped, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.OpenInNew, contentDescription = null)
                    Spacer(Modifier.size(8.dp))
                    Text("Start plan")
                }
            }
        }
    }
}

@Composable
private fun ActivityHistory(entries: List<String>) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(20.dp),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Activity", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            entries.takeLast(5).forEach { entry ->
                Text("• $entry", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

private fun isScreenReaderEnabled(context: Context): Boolean {
    val enabled = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
    val expected = ComponentName(context, ScreenReaderService::class.java).flattenToString()
    return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
}
