package com.studyassistant.mobile

data class ExecutionDecision(
    val usedScreenContext: Boolean,
    val shouldOpenWhatsApp: Boolean,
    val explanation: String,
)

object ActionExecutor {
    fun decide(request: String, screenContext: ScreenContext?): ExecutionDecision {
        val wantsWhatsApp = request.lowercase().contains("whatsapp")
        val currentApp = screenContext?.packageName.orEmpty()
        val alreadyInWhatsApp = currentApp == "com.whatsapp"
        return ExecutionDecision(
            usedScreenContext = screenContext != null,
            shouldOpenWhatsApp = wantsWhatsApp && !alreadyInWhatsApp,
            explanation = when {
                screenContext == null -> "No active screen context; using the requested app directly."
                alreadyInWhatsApp -> "Screen context shows WhatsApp is already active; continuing without reopening it."
                else -> "Screen context shows ${currentApp.ifBlank { "another app" }}; opening WhatsApp as requested.",
            },
        )
    }
}
