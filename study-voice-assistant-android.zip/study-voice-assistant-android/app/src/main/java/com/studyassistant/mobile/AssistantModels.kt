package com.studyassistant.mobile

data class CommandStep(
    val title: String,
    val detail: String,
    val status: StepStatus = StepStatus.PENDING,
)

enum class StepStatus { PENDING, ACTIVE, DONE, WAITING, FAILED }

data class AssistantPlan(
    val request: String,
    val steps: List<CommandStep>,
    val requiresConfirmation: Boolean,
)

data class ScreenContext(
    val packageName: String,
    val visibleText: String,
    val capturedAt: Long,
)

object CommandPlanner {
    fun plan(request: String, screenContext: ScreenContext? = null): AssistantPlan {
        val normalized = request.trim().lowercase()
        val screenStep = screenContext?.let {
            CommandStep("Use screen context", "Current app: ${it.packageName.ifBlank { "unknown" }}; ${it.visibleText.take(160)}")
        }
        return when {
            normalized.contains("whatsapp") && normalized.contains("hi") -> AssistantPlan(
                request = request,
                steps = listOfNotNull(
                    screenStep ?: CommandStep("Read current screen", "Use the enabled screen reader to understand the active app."),
                    CommandStep("Open WhatsApp", "Launch WhatsApp through an Android intent."),
                    CommandStep("Find Abay", "Resolve the contact using visible WhatsApp UI."),
                    CommandStep("Draft message", "Prepare the text: Hi"),
                    CommandStep("Confirm send", "Wait for your approval before sending the message.", StepStatus.WAITING),
                ),
                requiresConfirmation = true,
            )
            else -> AssistantPlan(
                request = request,
                steps = listOfNotNull(
                    screenStep,
                    CommandStep("Understand order", "Analyze the request and identify the required phone actions."),
                    CommandStep("Check permissions", "Verify that the required Android capabilities are enabled."),
                    CommandStep("Prepare action", "Build an execution plan and show it before consequential steps."),
                ),
                requiresConfirmation = true,
            )
        }
    }
}
