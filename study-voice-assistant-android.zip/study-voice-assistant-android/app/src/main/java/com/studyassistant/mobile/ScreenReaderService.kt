package com.studyassistant.mobile

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class ScreenReaderService : AccessibilityService() {
    override fun onServiceConnected() {
        super.onServiceConnected()
        ScreenContextStore.startContextUse()
    }

    override fun onDestroy() {
        ScreenContextStore.stopContextUse()
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!ScreenContextStore.acceptingContext) return
        val root = rootInActiveWindow ?: return
        val text = buildString {
            appendNodes(root, this)
        }.trim()
        if (text.isNotBlank()) {
            ScreenContextStore.update(
                ScreenContext(
                    packageName = event?.packageName?.toString().orEmpty(),
                    visibleText = text.take(MAX_CONTEXT_CHARS),
                    capturedAt = System.currentTimeMillis(),
                ),
            )
        }
    }

    override fun onInterrupt() = Unit

    private fun appendNodes(node: AccessibilityNodeInfo, output: StringBuilder) {
        node.text?.toString()?.trim()?.takeIf { it.isNotBlank() }?.let {
            output.append(it).append('\n')
        }
        node.contentDescription?.toString()?.trim()?.takeIf { it.isNotBlank() }?.let {
            output.append(it).append('\n')
        }
        for (index in 0 until node.childCount) {
            node.getChild(index)?.let { child ->
                appendNodes(child, output)
                child.recycle()
            }
        }
    }

    companion object {
        private const val MAX_CONTEXT_CHARS = 12000
    }
}

object ScreenContextStore {
    @Volatile
    var latest: ScreenContext? = null
        private set

    @Volatile
    var acceptingContext: Boolean = false
        private set

    fun startContextUse() {
        acceptingContext = true
    }

    fun stopContextUse() {
        acceptingContext = false
        latest = null
    }

    fun update(context: ScreenContext) {
        if (acceptingContext) latest = context
    }
}
