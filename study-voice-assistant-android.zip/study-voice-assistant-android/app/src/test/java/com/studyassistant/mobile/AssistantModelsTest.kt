package com.studyassistant.mobile

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class AssistantModelsTest {
    @Test
    fun whatsapp_order_creates_confirmation_plan() {
        val plan = CommandPlanner.plan("Open WhatsApp and send hi to Abay")
        assertTrue(plan.requiresConfirmation)
        assertEquals("Confirm send", plan.steps.last().title)
        assertEquals(StepStatus.WAITING, plan.steps.last().status)
    }

    @Test
    fun generic_order_creates_inspectable_plan() {
        val plan = CommandPlanner.plan("Read what is on my screen")
        assertEquals("Understand order", plan.steps.first().title)
        assertTrue(plan.steps.size >= 3)
    }
}
