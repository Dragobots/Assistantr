package com.studyassistant.mobile

import kotlin.test.Test
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class ActionExecutorTest {
    @Test
    fun active_whatsapp_context_is_consumed_and_prevents_reopen() {
        val decision = ActionExecutor.decide(
            "Open WhatsApp and send hi to Abay",
            ScreenContext("com.whatsapp", "Abay", 1L),
        )
        assertTrue(decision.usedScreenContext)
        assertFalse(decision.shouldOpenWhatsApp)
        assertTrue(decision.explanation.contains("already active"))
    }

    @Test
    fun cleared_context_is_ignored_and_requested_app_opens() {
        val decision = ActionExecutor.decide("Open WhatsApp", null)
        assertFalse(decision.usedScreenContext)
        assertTrue(decision.shouldOpenWhatsApp)
        assertTrue(decision.explanation.contains("No active screen context"))
    }
}
