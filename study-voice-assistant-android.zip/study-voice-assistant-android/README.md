# Study Assistant Android Prototype

This is the native Android prototype for the command-driven assistant. It accepts a natural-language order, creates a visible plan, checks whether the user-enabled screen-reading service is available, and can open WhatsApp for the first draft-message workflow.

## Current prototype behavior

The prototype understands the example order “Open WhatsApp and send hi to Abay.” It displays a plan containing screen context, WhatsApp launch, contact resolution, message drafting, and a confirmation checkpoint. The current prototype opens WhatsApp but does not send a message automatically. Contact resolution, message composition, AI-backed planning, speech recognition, and foreground wake-word service are the next native implementation steps.

Screen reading uses an Android `AccessibilityService`. The user must enable the service in Android Settings. When enabled, the service keeps a bounded in-memory snapshot of visible accessible text and does not upload it by itself.

## Build

Open this directory in Android Studio with JDK 17 and an Android SDK containing API 35. Let Android Studio install the Gradle wrapper and dependencies, then run the `app` configuration on an Android device or emulator.

The sandbox used to scaffold this project does not include Gradle or an Android SDK, so APK compilation and on-device testing must be completed in Android Studio or another Android build environment.

## Planned native milestones

The next milestones are AI-backed command planning, voice input and wake-word support, a foreground-service status indicator, a screen-context bridge, explicit confirmation UI before sending messages, and an activity history with a global stop action.
