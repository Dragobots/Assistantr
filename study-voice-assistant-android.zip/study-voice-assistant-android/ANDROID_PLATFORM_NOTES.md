# Android platform notes

The native prototype uses an Android AccessibilityService because Android documents that accessibility services may inspect UI content and act on behalf of a user through node actions and gestures. The service must be explicitly enabled by the user, and its configuration requests `canRetrieveWindowContent` for screen text access.

Android’s MediaProjection documentation states that screen capture requires user consent before each session. This prototype uses accessibility UI text rather than MediaProjection image capture for its first screen-reading implementation.

Android foreground-service documentation states that foreground services are for noticeable work and show a status-bar notification. A future wake-word implementation must use a visible foreground service and a clear stop control.

References:

- https://developer.android.com/guide/topics/ui/accessibility/service — Create an accessibility service
- https://developer.android.com/media/grow/media-projection — Media projection
- https://developer.android.com/develop/background-work/services/fgs — Foreground services overview
